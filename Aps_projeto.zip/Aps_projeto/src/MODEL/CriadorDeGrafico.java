package MODEL;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.RectangleInsets;
public class CriadorDeGrafico {
    private DadosInput objdadosinput;
    public CriadorDeGrafico() {
    }
    // coleta os dados e coloca no atributo de tipo DadosInput 
    public void coletarDados(float meta,float[] v_mensais) {
        DadosInput objdadosinput = new DadosInput();
        objdadosinput.setMeta(meta);
        objdadosinput.setValores_mensais(v_mensais);
        this.objdadosinput = objdadosinput;
    }
    // retorna o valor da meta
    public float valorMeta(){
        return objdadosinput.getMeta();
    }
    // retorna o valo mensal
     public float[] valorMensal(){
        return objdadosinput.getValores_mensais();
    }
    // Cria o dataset do grafico de comparação
    public CategoryDataset acrescentarDadosComparacao(float[] v_mensais, float meta){
        DefaultCategoryDataset data1 = new DefaultCategoryDataset();
        //add valor de emissão
            for(int i = 0; i < v_mensais.length;i++){
                data1.addValue(v_mensais[i],"Emissão","mes " + (1 + i));
            }
        //add valor da meta
            for(int i = 0; i < v_mensais.length;i++){
                data1.addValue(v_mensais[i] - ((meta/100)*v_mensais[i]),"Meta","mes " + (1 + i));
            }
        return data1;
    } 
    // cria o grafico de comparação
    public void criarGafrico(CategoryDataset data1){
        JFreeChart graficoBarra = ChartFactory.createBarChart(
                "Projeção de emissão",
                "meses",
                "CO2(t)", 
                data1);
        ChartPanel painelGraficoBarra = new ChartPanel(graficoBarra);
        JFrame telagrafico = new JFrame();
        painelGraficoBarra.setLayout(new GridLayout());
        telagrafico.getContentPane().add(painelGraficoBarra,BorderLayout.NORTH);
        telagrafico.pack();
        telagrafico.setVisible(true);
        painelGraficoBarra.setPreferredSize(new Dimension(1100,800));
        //Personalização do gráfico 
        graficoBarra.setBackgroundPaint(Color.WHITE);//cor de fundo 
        CategoryPlot plot = (CategoryPlot)graficoBarra.getPlot();
        plot.setBackgroundPaint(Color.WHITE);//cor de fundo do plot 
        plot.setDomainGridlinePaint(Color.WHITE);//cor das linhas de grade da categoria 
        plot.setRangeGridlinePaint(Color.WHITE);//cor das linhas de grade do valor 
        plot.setOutlineVisible(false);
        //personaliza barra
        Color verde = new Color(0 ,238, 118);
        Color vermelho = new Color(205, 0 ,0);
        BarRenderer renderer =(BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, vermelho);//Cor das barras da primeira serie 
        renderer.setSeriesPaint(1, verde); // cor das barras da segunda série
        renderer.setItemMargin(0.3);
        renderer.setMaximumBarWidth(0.5);
        //Personalização das legendas 
        graficoBarra.getLegend().setFrame(BlockBorder.NONE); //remove a borda da legnda 
        graficoBarra.getLegend().setItemLabelPadding(new RectangleInsets(5.0, 2.0, 10.0,2.0));
        graficoBarra.getLegend().setPadding(new RectangleInsets(20.0, 20.0, 0.0, 0.0));
        BarRenderer renderer2 = (BarRenderer) plot.getRenderer();
        renderer2.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        plot.getRenderer().setBaseItemLabelsVisible(true);
        // Ocultando o eixo Y do gráfico
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setVisible(false);
        plot.getDomainAxis().setTickLabelPaint(new Color(0, 0, 0));
        //Direção dos rotulos do eixo x
        plot.getDomainAxis().setCategoryLabelPositionOffset(4);
        // Definindo as margens inferior e superior do eixo X como zero
        plot.getDomainAxis().setLowerMargin(0);
        plot.getDomainAxis().setUpperMargin(0);
        // Definindo a margem entre as categorias no eixo X. Um 
        plot.getDomainAxis().setCategoryMargin(0.2);
    }
    //Cria o grafico de redução
    public void criarGraficoReducao(float meta,float[] mes){
        DefaultCategoryDataset data2 = new DefaultCategoryDataset();
       for(int i = 0; i < mes.length ; i++){
           data2.addValue((meta/100)* mes[i],"valor de emissão reduzida", "mes " + ( 1 + i));
       }
        JFreeChart graficoBarra2 = ChartFactory.createBarChart3D(
                "Redução de CO2",
                "meses",
                "CO2(t)", 
                data2);
        ChartPanel painelGraficoBarra = new ChartPanel(graficoBarra2);
        JFrame telagrafico = new JFrame();
        telagrafico.setBackground(Color.WHITE);
        painelGraficoBarra.setLayout(new GridLayout());
        telagrafico.getContentPane().add(painelGraficoBarra,BorderLayout.NORTH);
        telagrafico.pack();
        telagrafico.setVisible(true);
        painelGraficoBarra.setPreferredSize(new Dimension(1000,700));
        graficoBarra2.setBackgroundPaint(Color.WHITE);//cor de fundo 
        CategoryPlot plot = (CategoryPlot)graficoBarra2.getPlot();
        plot.setBackgroundPaint(Color.WHITE);//cor de fundo do plot 
        plot.setDomainGridlinePaint(Color.WHITE);//cor das linhas de grade da categoria 
        plot.setRangeGridlinePaint(Color.WHITE);//cor das linhas de grade do valor 
        plot.setOutlineVisible(false);
        Color verde = new Color(50, 205, 50);
        BarRenderer renderer =(BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, verde);//Cor das barras da primeira serie 
        renderer.setItemMargin(0.3);
        graficoBarra2.getLegend().setFrame(BlockBorder.NONE); //remove a borda da legnda 
        graficoBarra2.getLegend().setItemLabelPadding(new RectangleInsets(5.0, 2.0, 10.0,2.0));
        graficoBarra2.getLegend().setPadding(new RectangleInsets(20.0, 20.0, 0.0, 0.0));
        BarRenderer renderer2 = (BarRenderer) plot.getRenderer();
        renderer2.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        plot.getRenderer().setBaseItemLabelsVisible(true);
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setVisible(false);
        plot.getDomainAxis().setTickLabelPaint(new Color(0, 0, 0));
        plot.getDomainAxis().setCategoryLabelPositionOffset(4);
        plot.getDomainAxis().setLowerMargin(0);
        plot.getDomainAxis().setUpperMargin(0);
        plot.getDomainAxis().setCategoryMargin(0.2);
    }
}
