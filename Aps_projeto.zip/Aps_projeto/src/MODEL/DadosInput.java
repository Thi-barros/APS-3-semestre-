package MODEL;
public class DadosInput {
    private float valor_total_emitido;
    private float meta;
    private float[] valores_mensais;
    public float getValor_total_emitido() {
        return valor_total_emitido;
    }
    public float setValor_total_emitido(float[] valores_mensais) {
        for(int i = 0; i < valores_mensais.length ; i++){
            this.valor_total_emitido += valores_mensais[i];
        }
        return this.valor_total_emitido;
    }
    public float getMeta() {
        return meta;
    }
    public void setMeta(float meta) {
        this.meta = meta;
    }
    public float[] getValores_mensais() {
        return valores_mensais;
    }
    public void setValores_mensais(float[] valores_mensais) {
        this.valores_mensais = valores_mensais;
    }
}
