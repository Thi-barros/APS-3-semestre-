package CONTROLLER;

import MODEL.CriadorDeGrafico;
import VIEW.InserirDados;
import VIEW.OpcaoGrafico;
import org.jfree.data.category.CategoryDataset;

public class ControllerCriadorGrafico {
        

    private CriadorDeGrafico objcriadordegrafico;
    private InserirDados tela;
    private OpcaoGrafico tela2;

   

    public ControllerCriadorGrafico() {
    }
    
    
    // coleta os dados e os coloca no atributo
    public void coletarDados(float meta,float[] v_mensais){
        CriadorDeGrafico dados = new CriadorDeGrafico();
        dados.coletarDados(meta, v_mensais);
        this.objcriadordegrafico = dados;
    }

    
    // Cria o grafico de comparação
    public void criarGraficoComparacao(){
        CriadorDeGrafico grafico = new CriadorDeGrafico();
        
        // recebe o dataset do grafico
        CategoryDataset data = grafico.acrescentarDadosComparacao(objcriadordegrafico.valorMensal(),objcriadordegrafico.valorMeta());
        
        // cria o grafico com os valores recebidos
        grafico.criarGafrico(data);
        
    }
    
    public void criarGraficoReducao(){
        CriadorDeGrafico graficoreducao = new CriadorDeGrafico();
        
        graficoreducao.criarGraficoReducao(objcriadordegrafico.valorMeta(), objcriadordegrafico.valorMensal());
    }
    
    
}
